<?php

namespace Drupal\composer_manager\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\Process\Process;
use Symfony\Component\Process\Exception\ProcessFailedException;

class ComposerCommandForm extends FormBase {
  
  public function getFormId() {
    return 'composer_command_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['composer_command'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Comando Composer'),
      '#description' => $this->t('Introduce el comando de Composer que deseas ejecutar (p. ej., require drupal/modulename).'),
      '#required' => TRUE,
    ];

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Ejecutar comando'),
      '#button_type' => 'primary',
    ];

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $command = 'composer ' . $form_state->getValue('composer_command');
    $process = new Process(explode(' ', $command));
    try {
      $process->mustRun();
      \Drupal::messenger()->addMessage($this->t('Comando ejecutado con �xito: %command', ['%command' => $command]));
    } catch (ProcessFailedException $exception) {
      \Drupal::messenger()->addError($this->t('Error al ejecutar el comando: %error', ['%error' => $exception->getMessage()]));
    }
  }
}
3. Define la Ruta para el Formulario
En la misma carpeta composer_manager, crea un archivo composer_manager.routing.yml para definir la ruta al formulario en el men� de administraci�n:

yaml
Copiar c�digo
composer_manager.form:
  path: '/admin/config/development/composer-manager'
  defaults:
    _form: '\Drupal\composer_manager\Form\ComposerCommandForm'
    _title: 'Composer Manager'
  requirements:
    _permission: 'administer site configuration'